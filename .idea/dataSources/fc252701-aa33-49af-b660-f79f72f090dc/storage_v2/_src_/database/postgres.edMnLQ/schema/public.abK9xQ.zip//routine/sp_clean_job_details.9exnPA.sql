create function sp_clean_job_details(retention_days integer DEFAULT 7) returns integer
    security definer
    language plpgsql
as
$$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM cron.job_run_details
  WHERE 
    status = 'succeeded'
    AND start_time < NOW() - (retention_days || ' days')::INTERVAL;
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  
  RETURN deleted_count;
END;
$$;

alter function sp_clean_job_details(integer) owner to postgres;

grant execute on function sp_clean_job_details(integer) to anon;

grant execute on function sp_clean_job_details(integer) to authenticated;

grant execute on function sp_clean_job_details(integer) to service_role;

